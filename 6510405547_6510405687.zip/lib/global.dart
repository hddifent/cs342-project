import 'models/app_user.dart';

AppUser? currentAppUser;